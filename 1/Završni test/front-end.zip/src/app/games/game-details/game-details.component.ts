import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bgg-game-details',
  templateUrl: './game-details.component.html',
  styleUrls: ['./game-details.component.css']
})
export class GameDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
