import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
 
import { HomeComponent } from './core/home/home.component';
import { GameListComponent } from './games/game-list/game-list.component';
import { GameDetailsComponent } from './games/game-details/game-details.component';


const coreRoutes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'games', component: GameListComponent },
  { path: 'games/new', component: GameDetailsComponent },
  { path: 'games/:id/details', component: GameDetailsComponent },
  { path: '',   redirectTo: '/home', pathMatch: 'full' }
];
 
@NgModule({
  imports: [
    RouterModule.forRoot(coreRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }