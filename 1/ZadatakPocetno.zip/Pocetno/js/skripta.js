var boje = {
	rucak: "Crimson",
	pice: "Teal"
};